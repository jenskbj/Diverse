var debug = false;
var pressedKeys = [];
var images = [];
var pause = false;

var UP = 38;
var DOWN = 40;
var LEFT = 37;
var RIGHT = 39;

class Animation {
    constructor(spritesheet_path) {
        this.sheet = new Image();
        this.sheet.src = spritesheet_path;

        /* This will be true if the animation has run all the way through at least
        once since last set */
        this.done = false;
    }

    setup() {
        this.frameSize = this.sheet.height;
        this.frames = this.sheet.width/this.frameSize;
        this.timestamp = Date.now();
        this.speed = 1;
        this.currentFrame = 0;
        debug && console.log("Setup finished!");
        debug && console.log("Width: " + this.sheet.width);
        debug && console.log("Height: " + this.sheet.height);
        debug && console.log("Frame size: " + this.frameSize);
        debug && console.log("Frames: " + this.frames);
    }

    equals(needle) {
        return this.sheet.src.indexOf(needle) != -1;
    }

    getFrame() {
        var moment = Date.now();

        if(moment >= this.timestamp+1000/this.frames/this.speed) {
            this.currentFrame += this.currentFrame < this.frameSize*(this.frames-1) ? this.frameSize : -this.currentFrame;
            this.timestamp = moment;
        }

        // this.done = !this.done this.currentFrame
        return this.currentFrame;
    }
}

var animations = [
    new Animation("Sprites/Guy/idle.png"),
    new Animation("Sprites/Guy/walking.png"),
    new Animation("Sprites/Guy/blink.png"),
    new Animation("Sprites/Guy/down.png"),
    new Animation("Sprites/Guy/crouch.png")
];

var loadCount = 0;

function preload() {
    for(animation in animations) {
        animations[animation].sheet.onload = function() {
            animations[loadCount].setup();
            loadCount++;
            if(loadCount == animations.length) start();
        }
    }
}

preload();

function getAnimation(needle) {
    for(elem in animations) {
        if(animations[elem].sheet.src.indexOf(needle) != -1)
            return animations[elem];
    }

    return null;
}

// Returns random integer in range [min, max]
function randInt(min, max) {
    return Math.floor(min + Math.random()*(max+1-min));
}

document.body.addEventListener("keydown", function(e) {
    if(!isPressed(e.keyCode)) {
        pressedKeys.push(e.keyCode);
    }
    debug && console.log(pressedKeys);
});

document.body.addEventListener("keyup", function(e) {
    pressedKeys.splice(pressedKeys.indexOf(e.keyCode), 1);
    debug && console.log(pressedKeys);
});

function contains(array, object) {
    return array.indexOf(object) != -1;
}

function isPressed(keyCode) {
    return pressedKeys.indexOf(keyCode) != -1;
}
