var winWidth = window.innerWidth;
var winHeight = window.innerHeight;
var canvas = document.getElementById("canvas");
canvas.width = winWidth;
canvas.height = winHeight;
ctx = canvas.getContext("2d");
canvas.style.backgroundColor = "rgba(205, 254, 255, 1)";

class Character {
    constructor(xPos, yPos, width, height) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.width = width;
        this.height = height;
        this.xVel = 0;
        this.yVel = 0;
        this.accel = 0.3;
        this.grav = 0.25;
        this.friction = 0.4;
        this.xVelMax = 8;
        this.yVelMax = 20;
        this.centerX = this.xPos+this.width/2;
        this.centerY = this.yPos+this.height/2;
        this.timestamp = Date.now();
    }

    draw() {
        this.update();
    }

    colliding(where) {
        switch(where) {
            case "left":
                return this.xPos <= 0;

            case "right":
                return this.xPos + this.width >= winWidth;

            case "ground":
                return this.yPos + this.height >= winHeight;
        }
    }

    update(){}
}

class Player extends Character {
    constructor(xPos, yPos, width, height) {
        super(xPos, yPos, width, height);
        this.combo = [];
        this.animation = getAnimation("idle");
    }

    jump() {
        this.yVel = -this.yVelMax;
    }

    setAnimation(needle, speed) {
        this.animation = getAnimation(needle);
        this.animation.done = false;
        this.animation.speed = speed;
    }

    //
    update() {
        var counter = 0;
        var onBox, onGnd, onLeft, onRight;

        // Collision is calculated once for every pixel the player moves
        while(counter <= Math.abs(this.xVel) + Math.abs(this.yVel)) {

            // Boolean variables for collision are set
            onGnd = this.colliding("ground");
            onLeft = this.colliding("left");
            onRight = this.colliding("right");

            /* Logic for acceleration, friction, collisions and animations is
            executed once for every pixel the player is moved in the x-
            direction, but stops executing once it has been calculated for
            every pixel */
            if(counter <= Math.abs(this.xVel)) {

                /* The x-position is updated one pixel at a
                time (as long as the xVel is not zero, because
                then the character shouldn't move duh!) */
                if(this.xVel != 0) {
                    this.xPos += this.xVel < 0 ? -1 : 1;
                }

                // If player hits a wall; bounce back by reversing xVel
                if(onLeft || onRight) {
                    this.xVel *= -1;
                    this.xPos += 2*this.xVel/Math.abs(this.xVel);
                    // this.setAnimation("down", 1);
                    // this.setAnimation("test", "hello", "foo", "bar");
                }


                // Player controls
                if(isPressed(LEFT)) {

                    // If both left and right are pressed at the same time
                    if(isPressed(RIGHT)) {

                        // If player on ground, friction applies
                        if(onGnd) {
                            this.xVel += this.xVel < 0 ? this.friction : -this.friction;
                            if(Math.abs(this.xVel) <= this.friction) this.xVel = 0;
                        }

                        this.setAnimation("idle", 1);

                    // If only left is pressed, update xVel and set animation
                    } else if(this.xVel >= -this.xVelMax) {
                        this.xVel -= this.accel;
                        this.setAnimation("walking", 3);
                        this.flip = true;
                    }

                // If only right is pressed, update xVel and set animation
                } else if(isPressed(RIGHT) && this.xVel <= this.xVelMax) {
                    this.xVel += this.accel;
                    this.setAnimation("walking", 3);
                    this.flip = false;

                // If neither left nor right is pressed, friction applies
                } else if(this.xVel != 0) {
                    this.xVel += this.xVel < 0 ? this.friction : -this.friction;
                    if(Math.abs(this.xVel) <= this.friction) this.xVel = 0;
                } else {
                    // if(this.animation.isDone()) {
                    //     this.setAnimation("idle");
                    // }
                    //
                    // if(Date.now() > this.timestamp+3000 && !randInt(0, 2) && this.animation != getAnimation("blink")) {
                    //     this.animation = getAnimation("blink");
                    //     this.animation.speed = 0.3;
                    //     console.log("Blinking activated");
                    //     this.timestamp = Date.now();
                    // }
                    this.setAnimation("blink", 0.2);
                }

                // if(isPressed(DOWN)) {
                //     this.setAnimation("crouch");
                // }

                // Update centerX
                this.centerX = this.xPos+this.width/2;
            }

            //
            if(counter <= Math.abs(this.yVel)) {

                // Corresponding logic for y-position
                if(this.yVel != 0) {
                    this.yPos += this.yVel < 0 ? -1 : 1;
                }

                // Gravity applies when airborne
                if(!onGnd) {
                    if(this.yVel <= this.yVelMax) {
                        this.yVel += this.grav;
                    }

                // Can jump if on ground
                } else if(isPressed(UP)) {
                    this.jump(false);
                } else {
                    this.yVel = 0;
                }

                this.centerY = this.yPos+this.height/2;
            }

            counter++;
        }
    }

    draw() {
        this.update();

        // Flips the sprite
        ctx.translate(this.centerX, this.centerY);
        if(this.flip) ctx.scale(-1, 1);

        ctx.drawImage(this.animation.sheet, this.animation.getFrame(), 0,
            this.animation.frameSize, this.animation.frameSize, -this.width/2,
            -this.height/2, this.width, this.height
        );

        // Flips back
        if(this.flip) ctx.scale(-1, 1);
        ctx.translate(-this.centerX, -this.centerY);
    }
}

// class NPC extends Character {
//     setup() {
//         this.width = randInt(50, 200);
//         this.height = randInt(50, 200);
//         this.xPos = randInt(0, winWidth-this.width);
//         this.yPos = randInt(0, winHeight-this.height);
//         this.color = "rgb(" + randInt(0, 255) + ", " + randInt(0, 255) + ", " + randInt(0, 255) + ")";
//
//         console.log(super.setup() + "AI");
//     }
//
//     update() {
//         var onGnd = this.colliding("ground");
//
//         if(onGnd && randInt(0, 100) == 1) {
//             this.jump(false);
//         }
//
//         // If box is airborn, it is affected by gravity
//         if(!onGnd) {
//             if(this.yVel <= this.yVelMax) {
//                 this.yVel += this.grav;
//             }
//
//         // If box is on the ground and is not about to jump
//         }else if(!this.jumping) {
//             this.yVel = 0;
//
//             // Fix clipping into ground/stuttering
//             this.yPos = winHeight - this.height;
//
//         // If box is on the ground and jump was just called
//         }else{
//             this.jumping = false;
//         }
//
//         // Update position
//         this.xPos += this.xVel;
//         this.yPos += this.yVel;
//     }
// }

var characters = [];
characters.push(new Player(winWidth/2-40, winHeight/2-300, 80, 80));


function draw() {
    ctx.clearRect(0, 0, winWidth, winHeight);

    for(character in characters) {
        characters[character].draw();
    }

    window.requestAnimationFrame(draw);
}

function start() {
    console.log("GAME STARTED!");
    debug && console.log("Spritesheets loaded: " + loadCount);
    window.requestAnimationFrame(draw);
}
