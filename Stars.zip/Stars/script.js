// ::: GLOBAL VARIABLES :::
var stars = [];
var pressedKeys = [];
var mouseX = 0;
var mouseY = 0;
var crossEye = false;
var crossEyeDepth = 250;
var debugging = false;
var pause = false;


// ::: CANVAS SETTINGS :::
var canvas = document.getElementById("canvas");
var c = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var canvas2 = document.getElementById("canvas2");
var c2 = canvas2.getContext("2d");

canvas2.width = window.innerWidth/2;
canvas2.height = window.innerHeight;


// ::: EVENT LISTENERS :::

// Keypress listener
document.body.addEventListener("keydown", function(e) {
    // If the key is not already being pressed, add it to the array
    if(!isPressed(e.keyCode)) {
        pressedKeys.push(e.keyCode);
    }

    // If debugging is on, log pressed keys
    debugging && console.log("PRESSED KEYS: " + pressedKeys);

    // Toggle 3d if spacebar is pressed
    if(isPressed(32)) {
        crossEye = !crossEye;
        crossEyeDepth = 250;
        canvas.width *= crossEye ? 1/2 : 2;
        document.getElementById("canvas2").style.display = (crossEye ? "initial" : "none");
        debugging && console.log("CROSS-EYE 3D: " + crossEye);
    }

    // Toggle debugging if | is pressed
    if(isPressed(220)) {
        debugging = !debugging;
        console.log("DEBUG MODE: " + debugging);
    }

    // Toggle pause if p is pressed
    if(isPressed(80)) {
        pause = !pause;
        debugging && console.log("PAUSE: " + pause);
    }
});

// Keyrelease listener
document.body.addEventListener("keyup", function(e) {
    // If the key was being pressed, remove it from the array
    if(isPressed(e.keyCode)) {
        pressedKeys.splice(pressedKeys.indexOf(e.keyCode), 1);
    }

    debugging && console.log("PRESSED KEYS: " + pressedKeys);
});


// ::: OBJECT CONSTRUCTORS :::

// Star-object constructor
function Star() {
    // Random x-position
    this.x = -Math.floor(Math.random()*window.innerWidth+1) +
    Math.floor(Math.random()*window.innerWidth*3+1);

    // Random y-position
    this.y = -Math.floor(Math.random()*window.innerHeight+1) +
    Math.floor(Math.random()*window.innerHeight*3+1);

    // Initial values for radius, velocities, blur and opacity
    this.radius = 0.1;
    this.xVel, this.yVel, this.blur;
    this.alpha = 1;

    // Updates opacity, blur, radius, velocity and position
    this.update = function() {
        // Update opacity
        this.alpha = 1-this.radius/1000;

        // Update blur
        this.blur = this.radius;

        // Remove if invisible
        if(this.alpha <= 0) {
            stars.splice(stars.indexOf(this), 1);
        }

        if(!pause) {
            // Increase radius
            this.radius += this.radius/30;

            // Update velocities
            this.xVel = -(canvas.width/2-this.x)*this.radius/2000;
            this.yVel = -(canvas.height/2-this.y)*this.radius/2000;
        }else{
            this.xVel = 0;
            this.yVel = 0;
        }

        // UP
        if(isPressed(38)) {
            this.yVel += this.radius;
        }

        // DOWN
        if(isPressed(40)) {
            this.yVel -= this.radius;
        }

        // LEFT
        if(isPressed(37)) {
            this.xVel += this.radius;
        }

        // RIGHT
        if(isPressed(39)) {
            this.xVel -= this.radius;
        }

        // Update position
        this.x += this.xVel;
        this.y += this.yVel;
    }

    this.draw = function(offset) {
        c.shadowBlur = this.blur;
        c.shadowColor = "white";
        c.fillStyle = "rgba(215, 217, 255, " + this.alpha + ")";
        c.beginPath();
        c.arc(this.x - offset*this.radius/500, this.y, this.radius, 0, 2*Math.PI);
        c.fill();

        if(crossEye) {
            c2.shadowBlur = this.blur;
            c2.shadowColor = "white";
            c2.fillStyle = "rgba(215, 217, 255, " + this.alpha + ")";
            c2.beginPath();
            c2.arc(this.x + offset*this.radius/500, this.y, this.radius, 0, 2*Math.PI);
            c2.fill();
        }
    }
}


// ::: FUNCTIONS :::

// Updates the mouseX and mouseY variables (runs on mousemove and onload)
function getMousePosition() {
    mouseX = window.event.clientX;
    mouseY = window.event.clientY;
}

// Return true if the keyCode is found in the pressedKeys-array
function isPressed(keyCode) {
    return pressedKeys.indexOf(keyCode) != -1;
}

// Clears the context of the given canvas elements
function clear() {
    for(element in arguments) {
        canv = arguments[element];
        cont = canv.getContext("2d");
        cont.clearRect(0, 0, canv.width, canv.height);
    }
}

// Draws custom cursor
function drawCursor() {
    c.fillStyle = "red";
    c.beginPath();
    c.arc(mouseX, mouseY, 3, 0, 2*Math.PI);
    c.fill();

    if(crossEye) {
        c2.fillStyle = "red";
        c2.beginPath();
        c2.arc(mouseX, mouseY, 3, 0, 2*Math.PI);
        c2.fill();
    }
}

// Creates star-objects equal to the given amount
function createStars(amount) {
    if(!pause) {
        for(var i = 0; i < amount; i++) {
            stars.push(new Star());
        }
    }
}


// ::: DRAW-LOOP :::

// Started at onload
function draw() {
    clear(canvas, canvas2);
    drawCursor();
    createStars(3);

    // Draw and update all the stars
    for(var i = stars.length-1; i >= 0; i--) {
        stars[i].draw(crossEyeDepth);
        stars[i].update();
    }

    // Adjust 3d depth
    if(crossEye) {
        if(isPressed(68)) crossEyeDepth += 3;
        if(isPressed(70)) crossEyeDepth -= 3;
    }

    // Request that the browser calls the draw function to update the animation
    window.requestAnimationFrame(draw);
}
